/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package addressapp;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/**
 *
 * @author Miguel
 */
public class DateUtil {
    
    private static final String PATRO_DATA = "dd.MM.yyyy";
    private static final DateTimeFormatter FORMATEJADOR_DATA = DateTimeFormatter.ofPattern(PATRO_DATA);
    
    /**
     * @param data
     * @return
     */
    
    public static String format(LocalDate data){
        if(data==null)
          return null;
        return FORMATEJADOR_DATA.format(data);
    }
    
    /**
     * @param data
     * @return
     */
    
    public static LocalDate parse(String data){
        try{
            return FORMATEJADOR_DATA.parse(data,LocalDate::from);
        }
        catch(DateTimeParseException e){
            return null;
        }
    }
    
    /**
     * @param data
     * @return
     */
    
    public static boolean validDate(String data){
        return DateUtil.parse(data) != null;
    }
    
}
