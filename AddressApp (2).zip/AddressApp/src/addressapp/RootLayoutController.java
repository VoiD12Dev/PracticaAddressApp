/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package addressapp;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import java.io.File;
import javafx.stage.FileChooser;
import java.io.*;
import addressapp.AddressApp;
import java.io.FileReader;
import java.nio.file.Paths;


/**
 * FXML Controller class
 *
 * @author Miguel
 */
public class RootLayoutController implements Initializable {
    
    private AddressApp address_app;
    
    /**
     * @param address_app
     */
    
    public void setAddressApp(AddressApp address_app){
        this.address_app = address_app;
    }
    
    @FXML
    public void exit(){
        System.exit(0);
    }
    
    @FXML
    public void openFile(){
        File arxiu = this.mostraDialeg("open"); //pagina 66 del PDF
        if(arxiu != null){
            this.address_app.loadContactDataFromFile(arxiu);
        }
    }
    
    @FXML
    public void saveFile(){
        File arxiu = this.address_app.getContactFilePath();
        if (arxiu != null){
            this.address_app.saveContactDataToFile(arxiu);
        }
        else{
            this.saveAsFile();
        }
    }
    
    @FXML
    public void saveAsFile(){
        File arxiu = this.mostraDialeg("save");
        if(arxiu != null){
            if(!arxiu.getPath().endsWith(".txt")){
                arxiu = new File(arxiu.getPath() + ".txt");
            }
            this.address_app.saveContactDataToFile(arxiu);
        }
    }
    
    private File mostraDialeg (String tipus){
        File arxiu;
        FileChooser seleccionador = new FileChooser();
        FileChooser.ExtensionFilter extensio = new FileChooser.ExtensionFilter("Archivos de texto", "*.txt");
        seleccionador.getExtensionFilters().add(extensio);
        if(tipus.equals("save")){
            return arxiu = seleccionador.showSaveDialog(address_app.getPrimaryStage());
        }
        else{
            return arxiu = seleccionador.showOpenDialog(address_app.getPrimaryStage());
        }
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
